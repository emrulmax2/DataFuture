<?php

namespace App\Imports;

use App\Models\SexIdentifier;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Auth;

class SexIdentifierImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new SexIdentifier([
            'name' => $row['name'],
            'is_hesa' => isset($row['is_hesa']) ? $row['is_hesa'] : 0,
            'hesa_code' => (isset($row['is_hesa']) && $row['is_hesa'] == 1 && !empty($row['hesa_code']) ? $row['hesa_code'] : null),
            'is_df' => isset($row['is_df']) ? $row['is_df'] : 0,
            'df_code' => (isset($row['is_df']) && $row['is_df'] == 1 && !empty($row['df_code']) ? $row['df_code'] : null),
            'created_by' => Auth::id()
        ]);
    }
}
