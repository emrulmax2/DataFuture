<?php

namespace App\Http\Controllers\Student\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\StudentPersonalDetailsRequest;
use App\Models\Student;
use App\Models\StudentArchive;
use App\Models\StudentOtherDetail;
use Illuminate\Http\Request;

class PersonalDetailController extends Controller
{
    
}
