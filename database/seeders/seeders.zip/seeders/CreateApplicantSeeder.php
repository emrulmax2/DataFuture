<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Applicant;

class CreateApplicantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $applicants = [
            [
               'applicant_user_id'=>'1',
               'application_no'=>'',
               'title_id'=>'2',
               'first_name'=>'Abdul',
               'last_name'=>'Latif',
               'photo'=>'1686829687_2.png',
               'date_of_birth'=>'1986-11-25',
               'gender'=>'MALE',
               'submission_date'=>'2023-04-12',
               'status_id'=>'2',
               'nationality_id'=>'1',
               'country_id'=>'1',
               'referral_code'=>'4587',
               'created_by'=> 1,
            ],
        ];
    
        foreach ($applicants as $key => $applicant) {
            Applicant::create($applicant);
        }
    }
}
