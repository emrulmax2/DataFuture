<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\AcademicYear;

class CreateAcademicYearSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $academicyears = [
            [
               'name'=>'2023 - 2024',
               'is_hesa'=>'0',
               'hesa_code'=>'NULL',
               'is_df'=>'0',
               'df_code'=>'NULL',
               'from_date'=>'2023-09-01',
               'to_date'=>'2024-08-31',
               'target_date_hesa_report'=>'2023-11-01',
               'created_by'=> 1,
            ],
        ];
    
        foreach ($academicyears as $key => $academicyear) {
            AcademicYear::create($academicyear);
        }
    }
}
